const express = require("express");
const cors = require("cors");
const path = require("path");
const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "public"))); // Serve frontend

// Temporary contacts array
let contacts = [
  { id: 1, name: "John Doe", phone: "9876543210" },
  { id: 2, name: "Jane Smith", phone: "9123456789" }
];

// GET all contacts
app.get("/api/contacts", (req, res) => {
  res.json(contacts);
});

// POST new contact
app.post("/api/contacts", (req, res) => {
  const { name, phone } = req.body;
  const newContact = { id: contacts.length + 1, name, phone };
  contacts.push(newContact);
  res.status(201).json(newContact);
});

// DELETE contact
app.delete("/api/contacts/:id", (req, res) => {
  contacts = contacts.filter(c => c.id != req.params.id);
  res.json({ message: "Contact deleted" });
});

// Start server
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
